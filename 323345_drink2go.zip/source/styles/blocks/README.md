# Папка для стилей БЭМ-блоков

_header.scss_

```css
.header {}
.header__logo {}
.header__nav {}
```

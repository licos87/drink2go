/* в этот файл добавляет скрипты*/
/* Бургер меню */
import './burger';
/* Сладер ноивнок */
import './slider';
/* Сладер диапазона цен */
import '../vendor/noUiSlider/nouislider.js';
import './form-price-slider.js';
